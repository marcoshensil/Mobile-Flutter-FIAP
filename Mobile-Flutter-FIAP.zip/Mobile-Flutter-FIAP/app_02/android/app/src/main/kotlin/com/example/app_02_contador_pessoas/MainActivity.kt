package com.example.app_02_contador_pessoas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
