package com.example.app_05_imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
