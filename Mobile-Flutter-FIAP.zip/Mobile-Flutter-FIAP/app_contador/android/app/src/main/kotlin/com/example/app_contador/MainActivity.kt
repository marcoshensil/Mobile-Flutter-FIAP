package com.example.app_contador

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
