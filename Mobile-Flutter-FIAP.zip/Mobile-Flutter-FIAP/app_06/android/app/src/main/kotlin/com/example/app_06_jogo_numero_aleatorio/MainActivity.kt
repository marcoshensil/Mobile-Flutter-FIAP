package com.example.app_06_jogo_numero_aleatorio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
