package com.example.app_03_multiplicar_numeros

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
