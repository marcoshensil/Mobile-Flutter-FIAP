package com.example.app_01_meu_perfil

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
