/* 16. Armazenar dez números na memória do computador. Exibir os valores na ordem 
 * inversa à da digitação.
 * */

void main() {
  var numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  var numerosInvertidos = numeros.reversed;
  
  print("Numeros na ordem inversa a da digitação: $numerosInvertidos");
}
