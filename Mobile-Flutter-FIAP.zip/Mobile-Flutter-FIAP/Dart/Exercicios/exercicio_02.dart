// 2. Calcular e exibir a média aritmética de quatro valores quaisquer que serão digitados.

void main() {
  int valor1 = 10;
  int valor2 = 30;
  int valor3 = 50;
  int valor4 = 70;
    
  double media = (valor1 + valor2 + valor3 + valor4) / 4;
  print("A média aritmética dos valores é: $media");
}