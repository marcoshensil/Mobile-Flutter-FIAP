// 1. Entrar via teclado com a base e a altura de um retângulo, calcular e exibir sua área

void main() {
  double base = 10.5;
  double altura = 10.0;
  double area = base * altura;

  print("A área do retangulo é: $area");
}