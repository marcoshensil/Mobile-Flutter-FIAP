// 3. Entrar via teclado com o valor de uma temperatura em graus Celsius, 
// calcular e exibir sua temperatura equivalente em Fahrenheit.

void main() {
  double temperaturaCelsius = 37.0;
  double equivalenteEmFahrenheit = temperaturaCelsius * 1.8 + 32;
  print("A temperatura equivalente em Fahrenheit é: $equivalenteEmFahrenheit");
}