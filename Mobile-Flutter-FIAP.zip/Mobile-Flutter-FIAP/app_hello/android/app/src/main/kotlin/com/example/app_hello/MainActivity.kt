package com.example.app_hello

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
