package com.example.app_04_alcool_gasolina

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
